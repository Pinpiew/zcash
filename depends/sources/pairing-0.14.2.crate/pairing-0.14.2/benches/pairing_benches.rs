#![feature(test)]

extern crate pairing;
extern crate rand;
extern crate test;

mod bls12_381;
